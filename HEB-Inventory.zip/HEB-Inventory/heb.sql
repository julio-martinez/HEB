--
-- Create schema HEB
--

DROP DATABASE IF EXISTS heb;
CREATE DATABASE heb;
USE heb;

DROP TABLE IF EXISTS info;
CREATE TABLE info (
  `ID` int(10) unsigned NOT NULL,
  `Description` varchar(45) NOT NULL default '',
  `lastSold` varchar(45) NOT NULL default '',
   `ShelfLife` int(5) unsigned NOT NULL,
   `Department` varchar(45) NOT NULL default '',
   `Price` float (5) NOT NULL,
   `Unit` varchar(45) NOT NULL default '',
   `xFor` int(2) unsigned NOT NULL,
   `Cost` float (5) NOT NULL,
  PRIMARY KEY  (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS users;
CREATE TABLE users (
  `ID` int(10) unsigned NOT NULL,
  `Username` varchar(45) NOT NULL default '',
   `Password` varchar(45) NOT NULL default '',
   PRIMARY KEY  (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO users (`ID`,`Username`,`Password`) VALUES 
(1,'heb','testing');

INSERT INTO info (`ID`,`Description`,`lastSold`,`ShelfLife`,`Department`,`Price`,`Unit`,`xFor`,`Cost`) VALUES 
 (753542,'banana','9-5-2017',4,'Produce', 2.99 ,'lb',1, 0.44),
 (321654,'apples','9-6-2017',7,'Produce',1.49 ,'lb',1, 0.20),
 (95175,'Strawberry','9-7-2017',3,'Produce', 2.49 ,'lb',1, 0.10),
 (321753,'onion','9-8-2017',9,'Produce', 1.00 ,'Each',1, 0.05),
 (987654,'Tomato','9-9-2017',4,'Produce', 2.35 ,'lb',1, 0.20),
 (11122,'grapes','9-10-2017',7,'Produce', 4.00 ,'lb',1, 1.20),
 (124872,'Lettuce','9-11-2017',5,'Produce', 0.79 ,'lb',1, 0.10),
 (113,'bread','9-12-2017',14,'Grocery', 1.50 ,'Each',1, 0.12),
 (1189,'hamburger buns','9-13-2017',14,'Grocery', 1.75 ,'Each',1, 0.14),
 (12221,'pasta sauce','9-14-2017',23,'Grocery', 3.75 ,'Each',1, 1.00),
 (1111,'cheese slices','9-15-2017',20,'Grocery', 2.68 ,'Each',1, 0.40),
 (18939,'sliced turkey','9-16-2017',20,'Grocery', 3.29 ,'Each',1, 0.67),
 (90879,'tortilla chips','9-17-2017',45,'Grocery', 1.99 ,'Each',1, 0.14),
 (119290,'cereal','9-18-2017',40,'Grocery', 3.19 ,'Each',1, 0.19),
 (4629464,'canned vegtables','9-19-2017',200,'Grocery', 1.89 ,'Each',1, 0.19),
 (9000001,'headache medicine','9-20-2017',365,'Pharmacy', 4.89 ,'Each',1, 1.90),
 (9000002,'Migraine Medicine','9-21-2017',365,'Pharmacy', 5.89 ,'Each',1, 1.90),
 (9000003,'Cold and Flu','9-22-2017',365,'Pharmacy', 3.29 ,'Each',1, 1.90),
 (9000004,'Allegry Medicine','9-23-2017',365,'Pharmacy', 3.00 ,'Each',1, 1.25),
 (9000005,'Pain','9-24-2017',365,'Pharmacy', 2.89 ,'Each',1, 1.00);

