/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Inventory;

/**
 *
 * @author juliomartinez
 */
import static Inventory.InventoryApplication.lang;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;
import static Inventory.InventoryApplication.URL;
import static Inventory.InventoryApplication.PASSWORD;
import static Inventory.InventoryApplication.USER_NAME;

public final class Products {

    private final StringProperty description = new SimpleStringProperty();
    private final StringProperty lastSold = new SimpleStringProperty();
    private final StringProperty shelfLife = new SimpleStringProperty();
    private final StringProperty Department = new SimpleStringProperty();
    private final StringProperty price = new SimpleStringProperty();
    private final StringProperty Unit = new SimpleStringProperty();
    private final StringProperty xFor = new SimpleStringProperty();
    private final StringProperty cost = new SimpleStringProperty();
    
    
    /* Query Products ID from db */
    public static int getProductsId(Products product) {
        int productId = -1;
        try (Connection connection = DriverManager.getConnection(URL, USER_NAME, PASSWORD)) {
            String sql = "SELECT Id FROM info "
                    + "WHERE Description = ? ";
            PreparedStatement sqlStatement = connection.prepareStatement(sql);
            sqlStatement.setString(1, product.getDescription());
            ResultSet result = sqlStatement.executeQuery();
            if (result.next()) {
                productId = result.getInt("Id");
            }
        } catch (SQLException e) {
            System.out.println("SQLException: " + e.getMessage());
            System.out.println("SQLState: " + e.getSQLState());
            System.out.println("Error: " + e.getErrorCode());
        }
        return productId;
    }

    /* Querying Products from DB using the Product ID*/
    public static Products getProduct(int productId) {
        Products product = null;
        try (Connection connection = DriverManager.getConnection(URL, USER_NAME, PASSWORD)) {
            String sql = "SELECT * FROM info WHERE productId = ? ";
            PreparedStatement sqlStatement = connection.prepareStatement(sql);
            sqlStatement.setInt(1, productId);
            ResultSet result = sqlStatement.executeQuery();

            if (result.next()) {
                String description = result.getString("description");
                String Department = result.getString("department");
                String price = result.getString("price");
                String Unit = result.getString("Unit");
                String xFor = result.getString("xFor");
                String cost = result.getString("cost");
                product = new Products(description, Department, price, Unit, xFor, cost);
            }
        } catch (SQLException e) {
            System.out.println("SQLException: " + e.getMessage());
            System.out.println("SQLState: " + e.getSQLState());
            System.out.println("Error: " + e.getErrorCode());
        }
        return product;
    }

    @Override
    public String toString() {
        return getDescription();
    }

    public String getDescription() {
        return description.get();
    }

    public String getLastSold() {
        return lastSold.get();
    }

    public String getShelfLife() {
        return shelfLife.get();
    }

    public String getDepartment() {
        return Department.get();
    }

    public String getPrice() {
        return price.get();
    }

    public String getUnit() {
        return Unit.get();
    }

    public String getXFor() {
        return xFor.get();
    }

    public String getCost() {
        return cost.get();
    }

    public void setDescription(String description) {
        if (description == null || description.isEmpty()) {
            throw new IllegalArgumentException(lang.getString("description") + " " + lang.getString("missingInfoMessage"));
        } else {
            this.description.set(description);
        }
    }

    public void setLastSold(String lastSold) {
        if (lastSold == null || lastSold.isEmpty()) {
            throw new IllegalArgumentException(lang.getString("lastSold") + " " + lang.getString("missingInfoMessage"));
        } else {
            this.lastSold.set(lastSold);
        }
    }

    public void setShelfLife(String shelfLife) {
        if (shelfLife == null || shelfLife.isEmpty()) {
            throw new IllegalArgumentException(lang.getString("shelfLife") + " " + lang.getString("missingInfoMessage"));
        } else {
            this.shelfLife.set(shelfLife);
        }
    }

    public void setDepartment(String Department) {
        if (Department == null || Department.isEmpty()) {
            throw new IllegalArgumentException(lang.getString("Department") + " " + lang.getString("missingInfoMessage"));
        } else {
            this.Department.set(Department);
        }
    }

    public void setPrice(String price) {
        this.price.set(price);
    }

    public void setUnit(String Unit) {
        if (Unit == null || Unit.isEmpty()) {
            throw new IllegalArgumentException(lang.getString("Unit") + " " + lang.getString("missingInfoMessage"));
        } else {
            this.Unit.set(Unit);
        }
    }

    public void setXFor(String xFor) {
        if (xFor == null || xFor.isEmpty()) {
            throw new IllegalArgumentException(lang.getString("xFor") + " " + lang.getString("missingInfoMessage"));
        } else {
            this.xFor.set(xFor);
        }
    }

    public void setCost(String cost) {
        if (cost == null || cost.isEmpty()) {
            throw new IllegalArgumentException(lang.getString("cost") + " " + lang.getString("missingInfoMessage"));
        } else {
            this.cost.set(cost);
        }
    }

    public StringProperty descriptionProperty() {
        return description;
    }

    public StringProperty lastSoldProperty() {
        return lastSold;
    }

    public StringProperty shelfLifeProperty() {
        return shelfLife;
    }

    public StringProperty DepartmentProperty() {
        return Department;
    }

    public StringProperty priceProperty() {
        return price;
    }

    public StringProperty UnitProperty() {
        return Unit;
    }

    public StringProperty xForProperty() {
        return xFor;
    }

    public StringProperty costProperty() {
        return cost;
    }

    public Products(String description, String Department, String price, String Unit, String xFor, String cost) {
        setDescription(description);
        setDepartment(Department);
        setPrice(price);
        setUnit(Unit);
        setXFor(xFor);
        setCost(cost);
    }

    public Products(String lastSold, String shelfLife, String Department, String price, String Unit, String xFor, String cost) {
        this(lastSold + " " + shelfLife, Department, price, Unit, xFor, cost);
    }
}
