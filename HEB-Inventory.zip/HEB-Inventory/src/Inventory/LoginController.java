/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Inventory;

/**
 *
 * @author juliomartinez
 */
import static Inventory.InventoryApplication.lang;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.application.Platform;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

public class LoginController {
    private InventoryApplication mainHandler;
    private Stage stage;

    @FXML
    private TextField userNameField;

    @FXML
    private PasswordField passwordField;

    @FXML
    private void initialize() {
    }

    public void initLogin(InventoryApplication mainHandler, Stage stage) {
        this.stage = stage;
        this.mainHandler = mainHandler;
    }

    @FXML
    private void runLogin() {
        try {
            if (userNameField.getText() == null || userNameField.getText().isEmpty() || passwordField.getText() == null || passwordField.getText().isEmpty()) {
                Alert alert = new Alert(AlertType.WARNING);
                alert.setTitle("Enter username/password");
                alert.setHeaderText(lang.getString("userNameBlankMessage"));
                alert.initOwner(stage);
                alert.showAndWait();
                return;
            }
            mainHandler.login(userNameField.getText(), passwordField.getText());
        } catch (IOException ex) {
            Logger.getLogger(LoginController.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    @FXML
    private void runCancel() {
        Platform.exit();
    }

}
