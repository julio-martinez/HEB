/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Inventory;

/**
 * FXML Controller class
 *
 * @author juliomartinez
 */
import javafx.fxml.FXML;
import javafx.scene.control.RadioMenuItem;
import javafx.scene.control.ToggleGroup;
import javafx.scene.layout.BorderPane;
import javafx.stage.Stage;

public class MainWindowController {

    private Stage stage;

    @FXML
    private BorderPane rootPane;

    @FXML
    private RadioMenuItem monthlyView;
    @FXML
    private RadioMenuItem weeklyView;

    public MainWindowController() {
    }

	/**
	 * The initialize method is called after the constructor by JavaFX
	 */
	@FXML
    private void initialize() {

        ToggleGroup radioGroup = new ToggleGroup();
        monthlyView.setToggleGroup(radioGroup);
        weeklyView.setToggleGroup(radioGroup);
      //  radioGroup.selectedToggleProperty().addListener((obs, prevView, newView) -> switchCalendarView(newView));
    }

    /* Init main screen */
    public void initMainScreen(Stage mainStage) {
        stage = mainStage;
      //  switchCalendarView(monthlyView);
    }

 
}
