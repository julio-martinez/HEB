/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Inventory;

/**
 *
 * @author juliomartinez
 */
import java.io.BufferedWriter;
import java.io.IOException;
import java.nio.charset.Charset;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardOpenOption;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Locale;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.application.Application;
import javafx.application.Platform;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;

/**
 *
 * @author juliomartinez
 */
public abstract class InventoryApplication extends Application {

    // database info
    private final static String DRIVER = "com.mysql.jdbc.Driver";
    public final static String URL = "jdbc:mysql://localhost:3306/heb";
    public final static String USER_NAME = "root";
    public final static String PASSWORD = "tkd933";

    public static ResourceBundle lang = ResourceBundle.getBundle("lang", Locale.getDefault());

    /* The line below should be uncommented in case compiling for Windows file structure */
    private final static Path LOG_FILE = Paths.get(System.getProperty("user.home") + "/HEB/Logs.txt");
    private final static Path LOG_FOLDER = LOG_FILE.getParent();
    public static String loggedInUser;
    private static int loginAttempts = 0;
    public static boolean isLoggedIn = false;

    private Stage primaryStage;
    private AnchorPane root;

    public static void main(String[] args) {
        try {
            Class.forName(DRIVER);
            createLogFile();
            launch(args);
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(InventoryApplication.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    /* Launch Login screen */
    @Override
    public void start(Stage primaryStage){
        this.primaryStage = primaryStage;
        showLoginScreen();
    }

    /* push login screen to stage*/
    private void showLoginScreen() {

        try {
            FXMLLoader loader = new FXMLLoader();
            loader.setLocation(getClass().getResource("Login.fxml"));
            loader.setResources(lang);
            AnchorPane loginRoot = (AnchorPane) loader.load();
            Scene scene = new Scene(loginRoot);
            primaryStage.setScene(scene);
            LoginController controller = loader.getController();
            controller.initLogin(this, primaryStage);
            primaryStage.show();
        } catch (IOException ex) {
            Logger.getLogger(InventoryApplication.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    /**
     * Initialize and show the main screen
     */
    private void showMainScreen() {
        try {
            this.primaryStage.setTitle("HEB Inventory App " + lang.getString("applicationTitle"));
            
            FXMLLoader loader = new FXMLLoader();
            loader.setLocation(InventoryApplication.class.getResource("MainWindow.fxml"));
            loader.setResources(lang);
            root = (AnchorPane) loader.load();
            Scene scene = new Scene(root);
            primaryStage.setScene(scene);
            MainWindowController controller = loader.getController();
            controller.initMainScreen(primaryStage);
            primaryStage.centerOnScreen();
            primaryStage.show();
            /* Purpose of multithreading is to run the reminders in the background */
            // addRemindersToQueue();
        } catch (IOException ex) {
            Logger.getLogger(InventoryApplication.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

 /* Get next id from db */
    public static int getNextID(String idColumn, String table) {
        int nextID = -1;
        String sql = "SELECT MAX(" + idColumn + ") FROM " + table;
        try (Connection connection = DriverManager.getConnection(URL, USER_NAME, PASSWORD);
                Statement sqlStatement = connection.createStatement();
                ResultSet result = sqlStatement.executeQuery(sql);) {
            if (result.next()) {
                nextID = result.getInt(1) + 1;
            }

        } catch (SQLException e) {
            System.out.println("SQLException: " + e.getMessage());
            System.out.println("SQLState: " + e.getSQLState());
            System.out.println("Error: " + e.getErrorCode());
        }
        assert nextID > 0; // Failsafing 
        return nextID;
    }

    /* Login method into DB */
    public void login(String loginUser, String loginPass) throws IOException {
        String sql = "SELECT * FROM users";
        try (Connection connection = DriverManager.getConnection(URL, USER_NAME, PASSWORD)) {
            PreparedStatement sqlStatement = connection.prepareStatement(sql);
            sqlStatement.setString(1, loginUser);
            sqlStatement.setString(2, loginPass);
            ResultSet results = sqlStatement.executeQuery();
            if (results.next()) {
                isLoggedIn = true;
                loggedInUser = loginUser;
                writeToLogFile("User: ", loginUser + " had logged in");
                showMainScreen();
            } else {
                throw new IllegalArgumentException("username or password incorrect");
            }

        } catch (SQLException e) {
            System.out.println("SQLException: " + e.getMessage());
            System.out.println("SQLState: " + e.getSQLState());
            System.out.println("Error: " + e.getErrorCode());
        } catch (IllegalArgumentException e) {
            if (e.getMessage().equals("username or password incorrect")) {
                Alert alert = new Alert(AlertType.WARNING);
                alert.setTitle(lang.getString("badLoginTitle"));
                alert.setHeaderText(lang.getString("badLoginMessage") + "UNSUCCESSFUL LOGIN" + loginUser + " Attempt " + ++loginAttempts);
                alert.initOwner(primaryStage);
                alert.showAndWait();
                writeToLogFile("Failed login by: ", loginUser + " (Attempt " + ++loginAttempts + ")");
                //  Third strike and theyre out
                if (loginAttempts > 2) {
                    Platform.exit();
                }
            } else {
                System.out.println("SQLException: " + e.getMessage());
            }
        }
    }

    /* Log file creation */
    private static void createLogFile() {
        try {
            if (!Files.exists(LOG_FOLDER)) {
                Files.createDirectories(LOG_FOLDER);
            }

            if (!Files.exists(LOG_FILE)) {
                Files.createFile(LOG_FILE);
            }

        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    /* Write in the log file */
    public static void writeToLogFile(String action, String description) {
        try (BufferedWriter writer = Files.newBufferedWriter(LOG_FILE, Charset.forName("UTF-8"), StandardOpenOption.APPEND)) {
            String timeStamp = LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd h:mm:ss"));
            writer.newLine();
            writer.append(timeStamp + ": " + action + " - " + description);
        } catch (IOException e) {
            System.out.println("There was an error writing to " + LOG_FILE);
        }
    }
}
